/* Since the pypi build process does not run make,
 * it cannot autoconfigure.
 *
 * Reasonable defaults are in cfg/wigxjpf_config.h
 */

#define WIGXJPF_HAVE_THREAD 1
